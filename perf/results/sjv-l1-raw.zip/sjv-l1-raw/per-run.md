| Stage | Run | Throughput (req/s) | p50 (ms) | p95 (ms) | p99 (ms) | Correct (%) | Start-up (s) | Pinned events | of which MerchantLookup | Request thread (service log) |
| :--- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | :--- |
| baseline | 1 | 1027.9 | 147.03 | 510.49 | 815.50 | 99.95 | 13.5 | 0 | 0 | `Settlement requests run on thread Thread[#48,http-nio-8080-exec-1,5,main] (isVirtual=false)` |
| baseline | 2 | 1452.0 | 108.46 | 310.49 | 510.82 | 99.89 | 13.7 | 0 | 0 | `Settlement requests run on thread Thread[#48,http-nio-8080-exec-1,5,main] (isVirtual=false)` |
| baseline | 3 | 1644.3 | 82.59 | 316.32 | 524.64 | 100.00 | 17.6 | 0 | 0 | `Settlement requests run on thread Thread[#48,http-nio-8080-exec-1,5,main] (isVirtual=false)` |
| migrated | 1 | 1381.9 | 123.97 | 283.64 | 463.23 | 99.93 | 21.5 | 0 | 0 | `Settlement requests run on thread VirtualThread[#53,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
| migrated | 2 | 1039.5 | 161.39 | 355.86 | 556.94 | 98.02 | 14.2 | 0 | 0 | `Settlement requests run on thread VirtualThread[#53,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
| migrated | 3 | 1835.9 | 81.05 | 245.30 | 425.02 | 99.20 | 17.7 | 0 | 0 | `Settlement requests run on thread VirtualThread[#53,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
| pinned | 1 | 1944.2 | 78.84 | 195.13 | 375.09 | 99.67 | 11.1 | 8 | 8 | `Settlement requests run on thread VirtualThread[#50,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
| pinned | 2 | 1017.3 | 174.26 | 375.05 | 614.17 | 98.96 | 15.1 | 8 | 8 | `Settlement requests run on thread VirtualThread[#50,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
| pinned | 3 | 1720.4 | 83.48 | 233.12 | 473.17 | 99.22 | 13.5 | 8 | 8 | `Settlement requests run on thread VirtualThread[#50,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
| fixed | 1 | 1816.4 | 88.28 | 196.00 | 309.92 | 98.51 | 13.8 | 0 | 0 | `Settlement requests run on thread VirtualThread[#53,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
| fixed | 2 | 1896.7 | 80.31 | 214.00 | 336.99 | 98.68 | 15.9 | 0 | 0 | `Settlement requests run on thread VirtualThread[#51,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
| fixed | 3 | 1780.2 | 81.84 | 235.41 | 423.01 | 98.37 | 17.3 | 0 | 0 | `Settlement requests run on thread VirtualThread[#53,tomcat-handler-0]/runnable@ForkJoinPool-1-worker-1 (isVirtual=true)` |
